require 'active_support'
ActiveSupport::Deprecation.warn 'require "activesupport" is deprecated and will be removed in Rails 3. Use require "active_support" instead.'
